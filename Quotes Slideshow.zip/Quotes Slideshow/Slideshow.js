let slideIndex = 1;

// Function to show slides
function showSlides(n) {
    const slides = document.querySelectorAll('.Slides-content');
    const dots = document.querySelectorAll('.dot');

    if (n > slides.length) {
        slideIndex = 1;
    }

    if (n < 1) {
        slideIndex = slides.length;
    }

    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = 'none';
    }

    for (let i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(' active', '');
    }

    slides[slideIndex - 1].style.display = 'block';
    dots[slideIndex - 1].className += ' active';
}

// Function to change slides when clicking the previous/next buttons
function plusSlides(n) {
    showSlides(slideIndex += n);
}

// Function to change slides when clicking the navigation dots
function currentSlide(n) {
    showSlides(slideIndex = n);
}

// Initialize the slideshow
showSlides(slideIndex);

setInterval(function () {
    plusSlides(1);
}, 3000); // Change slide every 5 seconds

// Initialize the slideshow
showSlides(slideIndex);
