// JavaScript code for the responsive image slider with auto-change

document.addEventListener("DOMContentLoaded", function () {
    let slideIndex = 0;
    let timer;

    function showSlide(index) {
        const images = document.querySelectorAll('.image');
        const dots = document.querySelectorAll('.dot');

        if (index >= images.length) {
            slideIndex = 0;
        } else if (index < 0) {
            slideIndex = images.length - 1;
        }
// this display one image which is active
        images.forEach((image, i) => {
            if (i === slideIndex) {
                image.style.display = 'block';
            } else {
                image.style.display = 'none';
            }
        });

        dots.forEach((dot, i) => {
            dot.classList.remove('active-dot');
            if (i === slideIndex) {
                dot.classList.add('active-dot');
            }
        });
    }

    function prevSlide(n) {
        showSlide(slideIndex += n);
    }

    function nextSlide() {
        prevSlide(1);
    }

    function gotoSlide(index) {
        showSlide(index);
    }

    const prevButton = document.querySelector('.prev-button');
    const nextButton = document.querySelector('.next-button');

    prevButton.addEventListener('click', () => {
        // clearTimeout(timer);
        prevSlide(-1);
    });

    nextButton.addEventListener('click', () => {
        // clearTimeout(timer);
        nextSlide();
    });

    const dots = document.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            clearTimeout(timer);
            gotoSlide(index);
        });
    });

    function autoChange() {
        nextSlide(1);
        timer = setTimeout(autoChange, 3000); // Change slide every 3 seconds (adjust as needed)
    }

    autoChange(); // Start the automatic image change

    showSlide(slideIndex);
});
